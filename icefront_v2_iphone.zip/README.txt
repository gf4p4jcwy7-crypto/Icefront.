ICEFRONT V2
Prototype autonome pour iPhone.
Publier index.html avec GitHub Pages, puis ouvrir l'adresse dans Safari et choisir Partager > Sur l'écran d'accueil.
